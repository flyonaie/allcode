# cmake-template

#### 介绍
一个CMake Project的模板仓库。
