// @Author: Farmer Li, 公众号: 很酷的程序员/RealCoolEngineer
// @Date: 2021-05-09

#include "math/add.h"

int add_int(int x, int y) {
  return x + y;
}
