// @Author: Farmer Li, 公众号: 很酷的程序员/RealCoolEngineer
// @Date: 2021-05-10

#include "math/minus.h"

int minus_int(int x, int y) {
  return x - y;
}
