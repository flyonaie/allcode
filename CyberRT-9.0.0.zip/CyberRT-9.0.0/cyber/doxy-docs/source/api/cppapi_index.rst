

C++ API
====================

Topological communication APIs is actually implemented in ``node`` and ``reader/writer`` and ``client/service``.

.. toctree::

   cppapi

