// Author: Farmer Li, 公众号: 很酷的程序员/RealCoolEngineer
// Date: 2021-07-12

#ifndef SRC_C_NN_NN_H_
#define SRC_C_NN_NN_H_

#ifdef __cplusplus
extern "C" {
#endif

int argmax_float(float *x, int len);

#ifdef __cplusplus
}
#endif

#endif  // SRC_C_NN_NN_H_
